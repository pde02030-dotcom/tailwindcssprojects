/**
 * @typedef {Object} LeftRightTopBottom
 * @property {string} [left]
 * @property {string} [right]
 * @property {string} [top]
 * @property {string} [bottom]
 */
export {} // 이 파일은 모듈입니다”라고 말하는 표시
