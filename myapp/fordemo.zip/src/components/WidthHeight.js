/**
 * @typedef {Object} WidthHeight
 * @property {string} [width]
 * @property {string} [height]
 */
export {}
