const CopyMe = ({ ...props }) => {
  return <div {...props} />
}

export default CopyMe
